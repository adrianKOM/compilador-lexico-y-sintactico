﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CompiladorLEX
{


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Sintactico()
        {
            val_inicio();
            val_si();
            //  val_entero();
            val_cadena();
            val_para();

            val_do();
            //  val_escribir();
            // val_leer();
        }

        public void val_inicio()
        {
            string error;
            string tipo;
            int validacion = 0;
            int contador = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            DataGridViewRow row = (DataGridViewRow)errores.Rows[0].Clone();

            //VALIDAR DECLARACION DE VARIABLE INICIO
            for (int j = 0; j < arrayfila.Length; j++)
            {
                if (arrayfila[j] == "P/R de Inicio" && j == 0)
                {
                    validacion = 1; //validacion inicio 2

                    if (general(j) != 0)
                    {
                    }
                    else
                    {
                        error = "Error se espera la palabra FIN";
                        tipo = "Debe indicar el fin del programa";

                        row.Cells[0].Value = tipo; //tipo
                        row.Cells[1].Value = error; //descripcion
                        errores.Rows.Add(row);
                        break;
                    }
                }
                if (validacion == 0) //validacion 3
                {
                    error = "Error se espera la palabra INICIO";
                    tipo = "Debe indicar el inicio del programa";

                    row.Cells[0].Value = tipo; //tipo
                    row.Cells[1].Value = error; //descripcion
                    errores.Rows.Add(row);
                    break;
                }
            }
        }
        public void val_si()
        {
            string error;
            string tipo;
            int contador = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            DataGridViewRow row = (DataGridViewRow)errores.Rows[0].Clone();
            //VALIDAR DECLARACION DE si
            for (int j = 0; j < arrayfila.Length; j++)
            {
                if (arrayfila[j] == "P/R si Condicional")
                {
                    j = j + 1;
                    if (arrayfila[j] == "parentesis inicial")
                    {
                        j = j + 1;

                        if (arrayfila[j] == "Identificador")
                        {
                            j = j + 1;

                            if (arrayfila[j] == "signo igual comparativo" || arrayfila[j] == "signo mayor" || arrayfila[j] == "signo menor")
                            {
                                j = j + 1;

                                if (arrayfila[j] == "Texto" || arrayfila[j] == "Numero" || arrayfila[j] == "Identificador")
                                {
                                    j = j + 1;

                                    if (arrayfila[j] == "parentesis final")
                                    {
                                        j = j + 1;
                                        if (arrayfila[j] == "llave de inicio")
                                        {
                                            if (procesos(j) != 0)
                                            {
                                                j = procesos(j) + 1;

                                                if (arrayfila[j] == "P/R sino Condicional")
                                                {
                                                    j = j + 1;

                                                    if (arrayfila[j] == "llave de final")
                                                    {
                                                        j = j + 1;

                                                        if (procesos(j) != 0)
                                                        {
                                                        }
                                                        else
                                                        {
                                                            error = "Error necesita cerrar la llave";
                                                            tipo = "Declaracion SINO incorrecta";

                                                            row.Cells[0].Value = tipo; //tipo
                                                            row.Cells[1].Value = error; //descripcion
                                                            errores.Rows.Add(row);
                                                            break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        error = "Error necesita abrir la llave";
                                                        tipo = "Declaracion de SINO incorrecta";

                                                        row.Cells[0].Value = tipo; //tipo
                                                        row.Cells[1].Value = error; //descripcion
                                                        errores.Rows.Add(row);
                                                        break;
                                                    }
                                                }
                                                else
                                                {
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                error = "Error necesita cerrar la llave";
                                                tipo = "Declaracion de SI incorrecta";

                                                row.Cells[0].Value = tipo; //tipo
                                                row.Cells[1].Value = error; //descripcion
                                                errores.Rows.Add(row);
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            error = "Error necesita abrir la llave";
                                            tipo = "Declaracion de SI incorrecta";

                                            row.Cells[0].Value = tipo; //tipo
                                            row.Cells[1].Value = error; //descripcion
                                            errores.Rows.Add(row);
                                            break;
                                        }

                                    }
                                    else
                                    {
                                        error = "Error necesita cerrar el parentesis";
                                        tipo = "Declaracion de SI incorrecta";

                                        row.Cells[0].Value = tipo; //tipo
                                        row.Cells[1].Value = error; //descripcion
                                        errores.Rows.Add(row);
                                        break;
                                    }
                                }
                                else
                                {
                                    error = "Error necesita algo a comparar";
                                    tipo = "Declaracion de SI incorrecta";

                                    row.Cells[0].Value = tipo; //tipo
                                    row.Cells[1].Value = error; //descripcion
                                    errores.Rows.Add(row);
                                    break;
                                }
                            }
                            else
                            {
                                error = "Error necesita un signo comparativo";
                                tipo = "Declaracion de SI incorrecta";

                                row.Cells[0].Value = tipo; //tipo
                                row.Cells[1].Value = error; //descripcion
                                errores.Rows.Add(row);
                                break;
                            }
                        }
                        else
                        {
                            error = "Error necesita una variable";
                            tipo = "Declaracion de SI incorrecta";

                            row.Cells[0].Value = tipo; //tipo
                            row.Cells[1].Value = error; //descripcion
                            errores.Rows.Add(row);
                            break;
                        }
                    }
                    else
                    {
                        error = "Error le falta el parentesis inicial";
                        tipo = "Declaracion de SI incorrecta";

                        row.Cells[0].Value = tipo; //tipo
                        row.Cells[1].Value = error; //descripcion
                        errores.Rows.Add(row);
                        break;


                    }

                }

            }
        }

        public void val_cadena()
        {
            string error;
            string tipo;
            int contador = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            DataGridViewRow row = (DataGridViewRow)errores.Rows[0].Clone();
            //VALIDAR DECLARACION DE VARIABLE CADENA
            for (int j = 0; j < arrayfila.Length; j++)
            {
                if (arrayfila[j] == "P/R de tipo Cadena")
                {
                    j = j + 1;

                    if (arrayfila[j] == "Indentificador")
                    {
                        j = j + 1;

                        if (arrayfila[j] == "Simbolo de cierre")
                        {

                        }
                        else
                        {
                            error = "Error necesita cerrar la linea";
                            tipo = "Declaracion de VAR CADENA incorrecta";

                            row.Cells[0].Value = tipo; //tipo
                            row.Cells[1].Value = error; //descripcion
                            errores.Rows.Add(row);
                            break;
                        }
                    }
                    else
                    {

                    }
                }
            }

        }

        public void val_para()
        {
            string error;
            string tipo;
            int contador = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            DataGridViewRow row = (DataGridViewRow)errores.Rows[0].Clone();

            for (int j = 0; j < arrayfila.Length; j++)
            {
                if (arrayfila[j] == "P/R Para")
                {
                    j = j + 1;

                    if (arrayfila[j] == "Parentesis inicio")
                    {
                        j = j + 1;

                        if (arrayfila[j] == "Identificador")
                        {
                            j = j + 1;
                            if (arrayfila[j] == "Signo de igual")
                            {
                                j = j + 1;
                                if (arrayfila[j] == "Numero")
                                {
                                    j = j + 1;
                                    if (arrayfila[j] == "Simbolo de cierre")
                                    {
                                        j = j + 1;
                                        if (arrayfila[j] == "Identificador")
                                        {
                                            j = j + 1;

                                            if (arrayfila[j] == "Signo igual comparativo" || arrayfila[j] == "Signo mayor" || arrayfila[j] == "Signo menor")
                                            {
                                                j = j + 1;
                                                if (arrayfila[j] == "Numero" || arrayfila[j] == "Identificador")
                                                {
                                                    j = j + 1;
                                                    if (arrayfila[j] == "Simbolo de cierre")
                                                    {
                                                        j = j + 1;
                                                        if (arrayfila[j] == "Identificador")
                                                        {
                                                            j = j + 1;
                                                            if (arrayfila[j] == "Signo de igual")
                                                            {
                                                                j = j + 1;
                                                                if (arrayfila[j] == "Identificador")
                                                                {
                                                                    j = j + 1;
                                                                    if (arrayfila[j] == "Signo de adicion" || arrayfila[j] == "Signo de sustraccion")
                                                                    {
                                                                        j = j + 1;
                                                                        if (arrayfila[j] == "Numero")
                                                                        {
                                                                            j = j + 1;
                                                                            if (arrayfila[j] == "Parentesis final")
                                                                            {
                                                                                j = j + 1;
                                                                                if (arrayfila[j] == "Llave inicio")
                                                                                {
                                                                                    if (procesos(j) != 0)
                                                                                    {

                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        error = "Error necesita cerrar la llave";
                                                                                        tipo = "Declaracion de PARA incorrecta";

                                                                                        row.Cells[0].Value = tipo; //tipo
                                                                                        row.Cells[1].Value = error; //descripcion
                                                                                        errores.Rows.Add(row);
                                                                                        break;
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    error = "Error necesita abrir la llave";
                                                                                    tipo = "Declaracion de PARA incorrecta";

                                                                                    row.Cells[0].Value = tipo; //tipo
                                                                                    row.Cells[1].Value = error; //descripcion
                                                                                    errores.Rows.Add(row);
                                                                                    break;
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                error = "Error necesita cerrar el parentesis";
                                                                                tipo = "Declaracion de PARA incorrecta";

                                                                                row.Cells[0].Value = tipo; //tipo
                                                                                row.Cells[1].Value = error; //descripcion
                                                                                errores.Rows.Add(row);
                                                                                break;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            error = "Error necesita un numero";
                                                                            tipo = "Declaracion de PARA incorrecta";

                                                                            row.Cells[0].Value = tipo; //tipo
                                                                            row.Cells[1].Value = error; //descripcion
                                                                            errores.Rows.Add(row);
                                                                            break;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        error = "Error solo se acepta signos + o - ";
                                                                        tipo = "Declaracion de PARA incorrecta";

                                                                        row.Cells[0].Value = tipo; //tipo
                                                                        row.Cells[1].Value = error; //descripcion
                                                                        errores.Rows.Add(row);
                                                                        break;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    error = "Error necesita una variable";
                                                                    tipo = "Declaracion de PARA incorrecta";

                                                                    row.Cells[0].Value = tipo; //tipo
                                                                    row.Cells[1].Value = error; //descripcion
                                                                    errores.Rows.Add(row);
                                                                    break;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                error = "Error necesita el signo igual #";
                                                                tipo = "Declaracion de PARA incorrecta";

                                                                row.Cells[0].Value = tipo; //tipo
                                                                row.Cells[1].Value = error; //descripcion
                                                                errores.Rows.Add(row);
                                                                break;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            error = "Error necesita una variable";
                                                            tipo = "Declaracion de PARA incorrecta";

                                                            row.Cells[0].Value = tipo; //tipo
                                                            row.Cells[1].Value = error; //descripcion
                                                            errores.Rows.Add(row);
                                                            break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        error = "Error necesita el simbolo de cierre !";
                                                        tipo = "Declaracion de PARA incorrecta";

                                                        row.Cells[0].Value = tipo; //tipo
                                                        row.Cells[1].Value = error; //descripcion
                                                        errores.Rows.Add(row);
                                                        break;
                                                    }
                                                }
                                                else
                                                {
                                                    error = "Error necesita un numero a comparar";
                                                    tipo = "Declaracion de PARA incorrecta";

                                                    row.Cells[0].Value = tipo; //tipo
                                                    row.Cells[1].Value = error; //descripcion
                                                    errores.Rows.Add(row);
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                error = "Error necesita un signo comparativo";
                                                tipo = "Declaracion de PARA incorrecta";

                                                row.Cells[0].Value = tipo; //tipo
                                                row.Cells[1].Value = error; //descripcion
                                                errores.Rows.Add(row);
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            error = "Error necesita una variable";
                                            tipo = "Declaracion de PARA incorrecta";

                                            row.Cells[0].Value = tipo; //tipo
                                            row.Cells[1].Value = error; //descripcion
                                            errores.Rows.Add(row);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        error = "Error necesita el simbolo de cierre !";
                                        tipo = "Declaracion de PARA incorrecta";

                                        row.Cells[0].Value = tipo; //tipo
                                        row.Cells[1].Value = error; //descripcion
                                        errores.Rows.Add(row);
                                        break;
                                    }
                                }
                                else
                                {
                                    error = "Error necesita un numero a comparar";
                                    tipo = "Declaracion de PARA incorrecta";

                                    row.Cells[0].Value = tipo; //tipo
                                    row.Cells[1].Value = error; //descripcion
                                    errores.Rows.Add(row);
                                    break;
                                }
                            }
                            else
                            {
                                error = "Error necesita un signo comparativo";
                                tipo = "Declaracion de PARA incorrecta";

                                row.Cells[0].Value = tipo; //tipo
                                row.Cells[1].Value = error; //descripcion
                                errores.Rows.Add(row);
                                break;
                            }
                        }
                        else
                        {
                            error = "Error necesita variable";
                            tipo = "Declaracion de PARA incorrecta";

                            row.Cells[0].Value = tipo; //tipo
                            row.Cells[1].Value = error; //descripcion
                            errores.Rows.Add(row);
                            break;
                        }
                    }
                    else
                    {
                        error = "Error le falta el parentesis inicial";
                        tipo = "Declaracion de PARA incorrecta";

                        row.Cells[0].Value = tipo; //tipo
                        row.Cells[1].Value = error; //descripcion
                        errores.Rows.Add(row);
                        break;
                    }
                }
            }
        }

        public void val_do()
        {
            string error;
            string tipo;
            int contador = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            DataGridViewRow row = (DataGridViewRow)errores.Rows[0].Clone();

            for (int j = 0; j < arrayfila.Length; j++)
            {
                if (arrayfila[j] == "P/R Hacer")
                {
                    j = j + 1;

                    if (arrayfila[j] == "Llave inicio")
                    {
                        j = procesos(j);

                        if (j != 0)
                        {
                            j = j + 1;

                            if (arrayfila[j] == "P/R MIENTRAS")
                            {
                                j = j + 1;
                                if (arrayfila[j] == "Parentesis inicio")
                                {
                                    j = j + 1;
                                    if (arrayfila[j] == "Identificador")
                                    {
                                        j = j + 1;

                                        if (arrayfila[j] == "Signo igual comparativo" || arrayfila[j] == "Signo mayor" || arrayfila[j] == "Signo menor")
                                        {
                                            j = j + 1;
                                            if (arrayfila[j] == "Texto" || arrayfila[j] == "Numero" || arrayfila[j] == "Identificador")
                                            {
                                                j = j + 1;
                                                if (arrayfila[j] == "Parentesis final")
                                                {
                                                    j = j + 1;
                                                    if (arrayfila[j] == "Simbolo de cierre")
                                                    {

                                                    }
                                                    else
                                                    {
                                                        error = "Error necesita cerrar la linea";
                                                        tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                                        row.Cells[0].Value = tipo; //tipo
                                                        row.Cells[1].Value = error; //descripcion
                                                        errores.Rows.Add(row);
                                                        break;
                                                    }

                                                }
                                                else
                                                {
                                                    error = "Error necesita cerrar el parentesis";
                                                    tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                                    row.Cells[0].Value = tipo; //tipo
                                                    row.Cells[1].Value = error; //descripcion
                                                    errores.Rows.Add(row);
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                error = "Error necesita algo que comparar";
                                                tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                                row.Cells[0].Value = tipo; //tipo
                                                row.Cells[1].Value = error; //descripcion
                                                errores.Rows.Add(row);
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            error = "Error necesita un signo comparativo";
                                            tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                            row.Cells[0].Value = tipo; //tipo
                                            row.Cells[1].Value = error; //descripcion
                                            errores.Rows.Add(row);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        error = "Error se esperaba una variable";
                                        tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                        row.Cells[0].Value = tipo; //tipo
                                        row.Cells[1].Value = error; //descripcion
                                        errores.Rows.Add(row);
                                        break;
                                    }
                                }
                                else
                                {
                                    error = "Error le falta el parentesis incial";
                                    tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                    row.Cells[0].Value = tipo; //tipo
                                    row.Cells[1].Value = error; //descripcion
                                    errores.Rows.Add(row);
                                    break;
                                }
                            }
                            else
                            {
                                error = "Error se esperaba MIENTRAS";
                                tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                                row.Cells[0].Value = tipo; //tipo
                                row.Cells[1].Value = error; //descripcion
                                errores.Rows.Add(row);
                                break;
                            }
                        }
                        else
                        {
                            error = "Error necesita cerrar la llave";
                            tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                            row.Cells[0].Value = tipo; //tipo
                            row.Cells[1].Value = error; //descripcion
                            errores.Rows.Add(row);
                            break;
                        }
                    }
                    else
                    {
                        error = "Error necesita abrir la llave";
                        tipo = "Declaracion de HACER-MIENTRAS incorrecta";

                        row.Cells[0].Value = tipo; //tipo
                        row.Cells[1].Value = error; //descripcion
                        errores.Rows.Add(row);
                        break;
                    }
                }
            }
        }



        public int procesos(int posicion)
        {
            int contador = 0;
            int nueva_posicion = 0;
            int pos_final = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila_NUEVO = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila_NUEVO[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            for (int j = posicion; j < arrayfila_NUEVO.Length; j++)
            {
                if (arrayfila_NUEVO[j] == "llave de final")
                {
                    nueva_posicion = j;
                }

                pos_final = nueva_posicion;

            }
            return pos_final;

        }

        public int general(int posicion)
        {
            int contador = 0;
            int nueva_posicion = 0;
            int pos_final = 0;

            contador = dataGridView1.Rows.Count - 1;

            string[] arrayfila_NUEVO = new string[dataGridView1.Rows.Count];

            for (int i = 0; i < contador; i++)
            {
                arrayfila_NUEVO[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            for (int j = posicion; j < arrayfila_NUEVO.Length; j++)
            {
                if (arrayfila_NUEVO[j] == "P/R de Fin")
                {
                    nueva_posicion = j;
                }

                pos_final = nueva_posicion;

            }
            return pos_final;

        }
        public void lexico()
        {
            string REntrada = txtBEntrada.Text;

            char[] salto = { '\n' };
            char[] limitador = { ' ' };

            string[] RArray = REntrada.Split(salto);

            for (int i = 0; i < RArray.Length; i++)
            {
                string[] palabra = RArray[i].Split(limitador);

                for (int j = 0; j < palabra.Length; j++)
                {
                    palabra[j] = palabra[j].Replace("\n", " ");

                    if (palabra[j] != "")
                    {
                        DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();

                        row.Cells[0].Value = analizar(palabra[j]);
                        row.Cells[1].Value = palabra[j];
                        row.Cells[2].Value = j + 1;//columna
                        row.Cells[3].Value = i + 1;//fila
                        dataGridView1.Rows.Add(row);

                    }
                }

            }
        }

        public void limpia()
        {
            dataGridView1.Rows.Clear();
            errores.Rows.Clear();
        }



        public string analizar(string analizado)
        {
            string dato = "";
            switch (analizado)
            {
                case "#":
                    dato = "signo igual";
                    break;
                case "+":
                    dato = "signo de adicion";
                    break;
                case "-":
                    dato = "signo de sustraccion";
                    break;
                case "*":
                    dato = "signo de multiplicacion";
                    break;
                case "/":
                    dato = "signo de division";
                    break;
                case "!":
                    dato = "signo de cierre de linea";
                    break;
                case ">":
                    dato = "signo mayor";
                    break;
                case "<":
                    dato = "signo menor";
                    break;
                case "$":
                    dato = "signo igual comparativo";
                    break;
                case "{":
                    dato = "llave de inicio";
                    break;
                case "}":
                    dato = "llave de final";
                    break;
                case "(":
                    dato = "parentesis inicial";
                    break;
                case ")":
                    dato = "parentesis final";
                    break;
                case "YY":
                    dato = "AND";
                    break;
                case "OO":
                    dato = "OR";
                    break;
                case "XX":
                    dato = "NOT";
                    break;
                case "INICIO":
                    dato = "P/R de Inicio";
                    break;
                case "FIN":
                    dato = "P/R de Fin";
                    break;
                case "ENT":
                    dato = "P/R de Entero";
                    break;
                case "CAD":
                    dato = "P/R de Cadena";
                    break;
                case "SI":
                    dato = "P/R si Condicional";
                    break;
                case "SINO":
                    dato = "P/R sino Condicional";
                    break;
                case "PARA":
                    dato = "P/R Para";
                    break;
                case "HACER":
                    dato = "P/R Hacer";
                    break;
                case "MIENTRAS":
                    dato = "P/R Mientras";
                    break;
                case "SHOW":
                    dato = "P/R Mostrar";
                    break;
                case "READ":
                    dato = "P/R Leer";
                    break;
                case ",":
                    dato = "coma";
                    break;
                case ".":
                    dato = "punto";
                    break;
                default:
                    int valor = 0;
                    int validar = 0;
                    if (int.TryParse(analizado, out valor))
                    {
                        dato = "Numero";
                        validar = 1;
                    }
                    if (analizado.StartsWith("'") && analizado.EndsWith("'"))
                    {
                        dato = "Texto";
                        validar = 1;

                    }
                    if (validar == 0)
                    {
                        dato = "Identificador";
                    }
                    break;

            }
            return dato;
        }
        private void limpiar_Click(object sender, EventArgs e)
        {
            txtBEntrada.Clear();
            limpia();
        }

        private void txtBEntrada_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                // Agregar una línea al ListBox
                listBox1.Items.Add((listBox1.Items.Count + 1));
            }
        }

        private void txtBEntrada_TextChanged_1(object sender, EventArgs e)
        {
            
            // Actualizar el ListBox al detectar un cambio en el RichTextBox
            int numeroLineas = txtBEntrada.Lines.Length;
            if (numeroLineas < listBox1.Items.Count)
            {
                // Eliminar la última línea del ListBox
                listBox1.Items.RemoveAt(listBox1.Items.Count - 1);
            }
            else if (numeroLineas > listBox1.Items.Count)
            {
                // Agregar líneas adicionales al ListBox
                for (int i = listBox1.Items.Count + 1; i <= numeroLineas; i++)
                {
                    listBox1.Items.Add(i);
                }
            }
            limpia();
            lexico();
            Sintactico();
            
            
        }

        private void btnCambiarColor_Click(object sender, EventArgs e)
        {
            using (ColorDialog colorDialog = new ColorDialog())
            {
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    // Obtener el color seleccionado por el usuario
                    Color colorSeleccionado = colorDialog.Color;

                    // Cambiar el color del texto en el control RichTextBox
                    colores(colorSeleccionado);
                }
            }
        }


        public void colores(Color color)
        {
            string pattern = "";
            string[] palabras = { "INICIO", "SINO", "FIN", "MIENTRAS", "CAD", "SI", "PARA", "HACER", "SHOW", "READ" };

            foreach (var a in palabras)
            {
                pattern += a + "|";
            }
            Regex R = new Regex(pattern);
            MatchCollection matches = R.Matches(txtBEntrada.Text);

            foreach (Match m in matches)
            {
                txtBEntrada.Select(m.Index, m.Length);
                txtBEntrada.SelectionColor = color;
            }

            txtBEntrada.SelectionStart = txtBEntrada.Text.Length;
            txtBEntrada.SelectionLength = 0;
            txtBEntrada.SelectionColor = Color.Black;
        }


    }
}
